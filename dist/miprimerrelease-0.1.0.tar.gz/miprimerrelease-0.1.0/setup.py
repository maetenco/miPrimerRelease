from setuptools import setup, find_packages

setup(
    name="miPrimerRelease",                                 # Nombre del paquete
    version="0.1.0",                                        # Versión inicial
    packages=find_packages(),                               # Paquetes a incluir
    description="Un paquete pip simple de saludo",          # Breve descripción
    author="Marianela",                                     # Tu nombre
    author_email="marianela.encina@outlook.es",             # Tu correo electrónico
    url="https://github.com/maetenco/miPrimerRelease",      # URL del proyecto
)